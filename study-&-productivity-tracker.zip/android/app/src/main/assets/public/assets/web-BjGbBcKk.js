import{W as n}from"./index-sCgaUC2m.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
