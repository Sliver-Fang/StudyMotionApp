# 📱 Standalone Android APK Build Guide

Because the cloud sandbox container is running a lightweight, optimized Node.js runtime without the Java Development Kit (JDK) or Android SDK installed, **compiling native Android binaries (APKs/AABs) is done on your local computer** where these native environments are configured.

Once you build the project locally, the native APK will be generated automatically. You can copy the resulting file into this directory if you wish to track your APK binaries within your repository.

---

## 🚀 How to build your standalone Android APK in 3 Steps:

### Step 1: Download or Export your App
Export this project as a ZIP or clone the repository to your local computer.

### Step 2: Build and Sync with Capacitor
Run the setup script we created for you. It will compile the production-ready React build and sync it into your native Android source files:
```bash
# Set execute permission and run the setup helper
chmod +x setup-capacitor.sh
./setup-capacitor.sh
```

### Step 3: Generate the APK inside Android Studio
1. Open the `/android` directory of this project in **Android Studio**:
   ```bash
   npx cap open android
   ```
2. Wait for Gradle to finish sync (takes about 30 seconds).
3. In the top-level menu bar, go to:
   **Build** ➔ **Build Bundle(s) / APK(s)** ➔ **Build APK(s)**.
4. Once completed, a pop-up will appear in the bottom-right corner. Click **Locate**.
5. Your standalone installation-ready APK will be at:
   `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 📦 Copying the APK back into the codebase (Optional)
If you wish to host the APK in your code repository for others to download directly:
1. Copy the compiled `app-debug.apk` file from the build path.
2. Create an `AppApk` folder locally and rename your file to `main.apk`.
3. Save it at:
   `AppApk/main.apk`
